<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <script>
                    document.write(new Date().getFullYear())
                </script> © Mesinkasirpku.
            </div>
            <div class="col-sm-6">
                <div class="text-sm-end d-none d-sm-block">
                    Develop by by TIM IT MPKU
                </div>
            </div>
        </div>
    </div>
</footer>
</div>
<!-- end main content-->

</div>
<!-- END layout-wrapper -->



<!--start back-to-top-->
<button onclick="topFunction()" class="btn btn-danger btn-icon" id="back-to-top">
    <i class="ri-arrow-up-line"></i>
</button>
<!--end back-to-top-->



<!-- JAVASCRIPT -->
<script src="<?= base_url('assets/js/'); ?>configuration.js"></script>
<script src="<?= base_url('assets/libs/'); ?>bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?= base_url('assets/libs/'); ?>simplebar/simplebar.min.js"></script>
<script src="<?= base_url('assets/libs/'); ?>node-waves/waves.min.js"></script>
<script src="<?= base_url('assets/libs/'); ?>feather-icons/feather.min.js"></script>
<script src="<?= base_url('assets/js/'); ?>pages/plugins/lord-icon-2.1.0.js"></script>
<script src="<?= base_url('assets/js/'); ?>plugins.js"></script>

<!-- prismjs plugin -->
<script src="<?= base_url('assets/libs/'); ?>prismjs/prism.js"></script>
<script src="<?= base_url('assets/libs/'); ?>list.js/list.min.js"></script>
<script src="<?= base_url('assets/js/'); ?>pages/form-validation.init.js"></script>
<script src="<?= base_url('assets/libs/'); ?>list.pagination.js/list.pagination.min.js"></script>

<!-- listjs init -->
<script src="<?= base_url('assets/js/'); ?>pages/listjs.init.js"></script>

<!-- App js -->
<script src="<?= base_url('assets/js/'); ?>app.js"></script>
</body>

</html>