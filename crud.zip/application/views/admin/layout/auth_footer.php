        <!-- footer -->
        <footer class="footer start-0">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="text-center">
                            <p class="mb-0 text-muted">&copy; <script>
                                    document.write(new Date().getFullYear())
                                </script> Mesinkasirpku. Crafted with <i class="mdi mdi-heart text-danger"></i> by TIM IT MPKU</p>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- end Footer -->
        </div>
        <!-- end auth-page-wrapper -->

        <!-- JAVASCRIPT -->
        <script src="<?= base_url('assets/'); ?>libs/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="<?= base_url('assets/'); ?>libs/simplebar/simplebar.min.js"></script>
        <script src="<?= base_url('assets/'); ?>libs/node-waves/waves.min.js"></script>
        <script src="<?= base_url('assets/'); ?>libs/feather-icons/feather.min.js"></script>
        <script src="<?= base_url('assets/'); ?>js/pages/plugins/lord-icon-2.1.0.js"></script>
        <script src="<?= base_url('assets/'); ?>js/plugins.js"></script>

        <!-- prismjs plugin -->
        <script src="<?= base_url('assets/'); ?>libs/prismjs/prism.js"></script>

        <!-- particles js -->
        <script src="<?= base_url('assets/'); ?>libs/particles.js/particles.js"></script>
        <!-- particles app js -->
        <script src="<?= base_url('assets/'); ?>js/pages/particles.app.js"></script>
        <!-- password-addon init -->
        <script src="<?= base_url('assets/'); ?>js/pages/password-addon.init.js"></script>

        <script src="<?= base_url('assets/'); ?>js/app.js"></script>
        </body>

        </html>